
const crypto = require('crypto');

const SECRETO = process.env.JWT_SECRET;

if (!SECRETO) {
    throw new Error('Falta configurar JWT_SECRET en el servidor');
}

function crearToken(alumno) {
    const datos = {
        id: alumno.id,
        email: alumno.email,
        exp: Date.now() + 8 * 60 * 60 * 1000
    };

    const contenido = Buffer.from(JSON.stringify(datos)).toString('base64url');

    const firma = crypto
        .createHmac('sha256', SECRETO)
        .update(contenido)
        .digest('base64url');

    return contenido + '.' + firma;
}

function verificarToken(req, res, next) {
    const autorizacion = req.headers.authorization || '';
    const token = autorizacion.startsWith('Bearer ')
        ? autorizacion.slice(7)
        : '';

    const partes = token.split('.');

    if (partes.length !== 2) {
        return res.status(401).json({ mensaje: 'Sesión no válida. Iniciá sesión.' });
    }

    const [contenido, firma] = partes;

    const firmaEsperada = crypto
        .createHmac('sha256', SECRETO)
        .update(contenido)
        .digest('base64url');

    const firmaBuffer = Buffer.from(firma);
    const esperadaBuffer = Buffer.from(firmaEsperada);

    if (
        firmaBuffer.length !== esperadaBuffer.length ||
        !crypto.timingSafeEqual(firmaBuffer, esperadaBuffer)
    ) {
        return res.status(401).json({ mensaje: 'Token no válido.' });
    }

    try {
        const datos = JSON.parse(
            Buffer.from(contenido, 'base64url').toString()
        );

        if (!datos.id || datos.exp < Date.now()) {
            return res.status(401).json({ mensaje: 'La sesión venció. Iniciá sesión nuevamente.' });
        }

        req.usuario = datos;
        next();

    } catch (error) {
        return res.status(401).json({ mensaje: 'Token no válido.' });
    }
}

module.exports = { crearToken, verificarToken };
