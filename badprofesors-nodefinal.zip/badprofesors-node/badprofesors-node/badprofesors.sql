-- ============================================================
--  BadProfesors API - tablas y datos de prueba (MySQL)
--  Entidades: Alumno, Docente, Encuesta (Persona es abstracta, no tiene tabla)
--  Las tablas también las crea Spring solo (ddl-auto=update), este script
--  sirve para crearlas a mano y cargar datos de ejemplo.
-- ============================================================

SET NAMES utf8mb4;
CREATE DATABASE IF NOT EXISTS badprofesors CHARACTER SET utf8mb4;
USE badprofesors;

CREATE TABLE IF NOT EXISTS Alumno (
    id     BIGINT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(255),
    email  VARCHAR(255) UNIQUE,
    curso  VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS Docente (
    id      BIGINT PRIMARY KEY AUTO_INCREMENT,
    nombre  VARCHAR(255),
    materia VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS Encuesta (
    id           BIGINT PRIMARY KEY AUTO_INCREMENT,
    fecha        DATE,
    alumno_id    BIGINT,
    docente_id   BIGINT,
    comunicacion VARCHAR(255),
    cantMejoras  INT NOT NULL DEFAULT 0,
    comentarios  VARCHAR(500),
    puntaje      INT NOT NULL DEFAULT 0,
    FOREIGN KEY (alumno_id)  REFERENCES Alumno(id)  ON DELETE CASCADE,
    FOREIGN KEY (docente_id) REFERENCES Docente(id) ON DELETE CASCADE
);

-- ---------------- Datos de prueba (inventados) ----------------
INSERT INTO Docente (nombre, materia) VALUES
('Prof. A', 'Matemática'), ('Prof. B', 'Lengua'), ('Prof. C', 'Historia'),
('Prof. D', 'Física'), ('Prof. E', 'Inglés'), ('Prof. F', 'Geografía');

INSERT INTO Alumno (nombre, email, curso) VALUES
('Alumno 1', 'alumno1@mail.com', 'Quinto primera'),
('Alumno 2', 'alumno2@mail.com', 'Quinto primera'),
('Alumno 3', 'alumno3@mail.com', 'Quinto segunda'),
('Alumno 4', 'alumno4@mail.com', 'Quinto tercera'),
('Alumno 5', 'alumno5@mail.com', 'Quinto tercera'),
('Alumno 6', 'alumno6@mail.com', 'Quinto cuarta');

INSERT INTO Encuesta (fecha, alumno_id, docente_id, comunicacion, cantMejoras, comentarios, puntaje) VALUES
('2026-09-18', 1, 1, 'buena',     1, 'Explica claro',     12),
('2026-09-20', 2, 1, 'regular',   2, 'A veces aburrido',  76),
('2026-09-25', 3, 2, 'excelente', 0, 'Muy buena clase',   0),
('2026-10-02', 4, 2, 'buena',     1, '',                  30),
('2026-10-05', 4, 3, 'mala',      3, 'No explica nada',   100),
('2026-10-06', 5, 3, 'regular',   2, '',                  68),
('2026-10-08', 5, 4, 'regular',   2, '',                  68),
('2026-10-09', 6, 1, 'buena',     0, 'Fácil de entender', 12),
('2026-10-10', 6, 5, 'excelente', 0, '',                  2),
('2026-10-11', 1, 4, 'mala',      2, 'Nunca responde',    100);

-- ---------------- Consultas útiles ----------------
-- Promedio de puntaje por docente
SELECT d.nombre, d.materia, ROUND(AVG(e.puntaje), 1) AS promedio
FROM Docente d JOIN Encuesta e ON e.docente_id = d.id
GROUP BY d.id, d.nombre, d.materia ORDER BY promedio DESC;

-- Malo / regular / bueno por curso
SELECT a.curso, COUNT(*) AS total,
       SUM(CASE WHEN e.puntaje >= 50 THEN 1 ELSE 0 END) AS malos,
       SUM(CASE WHEN e.puntaje >= 30 AND e.puntaje < 50 THEN 1 ELSE 0 END) AS regulares,
       SUM(CASE WHEN e.puntaje < 30 THEN 1 ELSE 0 END) AS buenos
FROM Encuesta e JOIN Alumno a ON e.alumno_id = a.id
GROUP BY a.curso;
