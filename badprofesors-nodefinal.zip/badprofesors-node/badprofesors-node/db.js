// Conexión a MySQL (cambiá usuario y contraseña si hace falta)
const mysql = require('mysql2/promise');

module.exports = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: 'root',
  database: 'badprofesors',
  timezone: 'Z',
  dateStrings: true   // las fechas salen como "2026-10-05"
});
