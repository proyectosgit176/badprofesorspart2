const router = require('express').Router();
const db = require('../db');

// Misma cuenta que hacía script.js (más puntaje = peor)
function calcularPuntaje(comunicacion, cantMejoras, comentarios) {
  let total = 0;
  if (comunicacion === 'buena') total = 20;
  if (comunicacion === 'regular') total = 50;
  if (comunicacion === 'mala') total = 80;
  total = total + cantMejoras * 8;

  const texto = comentarios.toLowerCase();
  const malas = ['malo', 'pesimo', 'peor', 'horrible', 'nunca', 'no entiendo', 'no explica', 'aburrido'];
  const buenas = ['bueno', 'claro', 'fácil', 'entretenido', 'agradable', 'excelente'];
  for (const palabra of malas) if (texto.includes(palabra)) total += 10;
  for (const palabra of buenas) if (texto.includes(palabra)) total -= 8;

  if (total < 0) total = 0;
  if (total > 100) total = 100;
  return total;
}

function crearMensaje(puntaje, docente) {
  if (puntaje >= 75) return 'Muy malo. ' + docente + ' necesita mejora urgente.';
  if (puntaje >= 50) return 'Malo. ' + docente + ' muestra problemas importantes.';
  if (puntaje >= 30) return 'Regular. Hay áreas a mejorar para que la experiencia sea más positiva.';
  return 'Aceptable. La percepción no es mala, pero siempre hay espacio para mejorar.';
}

// Arma la respuesta con las 3 barras y el mensaje
function armarRespuesta(e, alumno, docente) {
  return {
    id: e.id,
    fecha: e.fecha,
    alumno,
    docente,
    comunicacion: e.comunicacion,
    cantMejoras: e.cantMejoras,
    comentarios: e.comentarios,
    puntaje: e.puntaje,
    malo: e.puntaje,
    regular: 100 - Math.abs(e.puntaje - 50) * 2,
    bueno: 100 - e.puntaje,
    mensaje: crearMensaje(e.puntaje, docente.nombre)
  };
}

// Lista de encuestas (con alumno y docente)
router.get('/', async (req, res) => {
  const [filas] = await db.query(`
    SELECT e.*, a.nombre AS alumnoNombre, a.email, a.curso, d.nombre AS docenteNombre, d.materia
    FROM Encuesta e
    JOIN Alumno a ON e.alumno_id = a.id
    JOIN Docente d ON e.docente_id = d.id`);
  res.json(filas.map(f => armarRespuesta(
    f,
    { id: f.alumno_id, nombre: f.alumnoNombre, email: f.email, curso: f.curso },
    { id: f.docente_id, nombre: f.docenteNombre, materia: f.materia }
  )));
});

// Enviar encuesta. Body: { alumno:{id}, docente:{id}, comunicacion, cantMejoras, comentarios }
router.post('/', async (req, res) => {
  const { comunicacion, cantMejoras = 0 } = req.body;
  const comentarios = req.body.comentarios || '';

  const [alumnos] = await db.query('SELECT * FROM Alumno WHERE id = ?', [req.body.alumno.id]);
  if (alumnos.length === 0) return res.status(404).json({ mensaje: 'No existe el alumno' });
  const [docentes] = await db.query('SELECT * FROM Docente WHERE id = ?', [req.body.docente.id]);
  if (docentes.length === 0) return res.status(404).json({ mensaje: 'No existe el docente' });

  const puntaje = calcularPuntaje(comunicacion, cantMejoras, comentarios);
  const fecha = new Date().toISOString().slice(0, 10);

  const [r] = await db.query(
    `INSERT INTO Encuesta (fecha, alumno_id, docente_id, comunicacion, cantMejoras, comentarios, puntaje)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [fecha, alumnos[0].id, docentes[0].id, comunicacion, cantMejoras, comentarios, puntaje]
  );

  res.json(armarRespuesta(
    { id: r.insertId, fecha, comunicacion, cantMejoras, comentarios, puntaje },
    alumnos[0],
    docentes[0]
  ));
});

// Malo / regular / bueno por curso
router.get('/estadisticas', async (req, res) => {
  const [filas] = await db.query(`
    SELECT a.curso, COUNT(*) AS total,
      SUM(e.puntaje >= 50) AS malos,
      SUM(e.puntaje >= 30 AND e.puntaje < 50) AS regulares,
      SUM(e.puntaje < 30) AS buenos
    FROM Encuesta e JOIN Alumno a ON e.alumno_id = a.id
    GROUP BY a.curso ORDER BY a.curso`);
  // SUM() llega como texto desde MySQL: se pasa a número
  res.json(filas.map(f => ({ ...f, malos: +f.malos, regulares: +f.regulares, buenos: +f.buenos })));
});

module.exports = router;
