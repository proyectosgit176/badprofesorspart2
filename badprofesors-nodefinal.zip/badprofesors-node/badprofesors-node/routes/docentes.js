const router = require('express').Router();
const db = require('../db');

router.get('/', async (req, res) => {
  const [filas] = await db.query('SELECT * FROM Docente');
  res.json(filas);
});

router.post('/', async (req, res) => {
  const { nombre, materia } = req.body;
  const [r] = await db.query('INSERT INTO Docente (nombre, materia) VALUES (?, ?)', [nombre, materia]);
  res.json({ id: r.insertId, nombre, materia });
});

module.exports = router;
