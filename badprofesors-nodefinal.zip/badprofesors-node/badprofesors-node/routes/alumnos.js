const router = require('express').Router();
const db = require('../db');

// Lista de alumnos
router.get('/', async (req, res) => {
  const [filas] = await db.query('SELECT * FROM Alumno');
  res.json(filas);
});

// Ingresar: busca la cuenta por email
router.get('/email/:email', async (req, res) => {
  const email = req.params.email.trim().toLowerCase();
  const [filas] = await db.query('SELECT * FROM Alumno WHERE email = ?', [email]);
  if (filas.length === 0) return res.status(404).json({ mensaje: 'No hay cuenta con ese email' });
  res.json(filas[0]);
});

// Crear cuenta
router.post('/', async (req, res) => {
  const { nombre, curso } = req.body;
  const email = req.body.email.trim().toLowerCase();

  const [existe] = await db.query('SELECT id FROM Alumno WHERE email = ?', [email]);
  if (existe.length > 0) return res.status(409).json({ mensaje: 'Ya existe una cuenta con ese email' });

  const [r] = await db.query('INSERT INTO Alumno (nombre, email, curso) VALUES (?, ?, ?)', [nombre, email, curso]);
  res.json({ id: r.insertId, nombre, email, curso });
});

module.exports = router;
