const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());
const path = require('path');

app.use(express.static(path.join(__dirname, '..', 'badprofesors', 'sitio')));
app.use('/api/alumnos', require('./routes/alumnos'));
app.use('/api/docentes', require('./routes/docentes'));
app.use('/api/encuestas', require('./routes/encuestas'));

// Manejo de errores: si algo falla se responde con un mensaje
app.use((err, req, res, next) => {
  console.error(err);
  res.status(err.status || 500).json({ mensaje: err.message });
});

app.listen(8080, () => console.log('API lista en http://localhost:8080'));
