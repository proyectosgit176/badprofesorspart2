
const router = require('express').Router();
const db = require('../db');
const { verificarToken } = require('../auth');

// Misma cuenta que hacía script.js (más puntaje = peor)
function calcularPuntaje(comunicacion, cantMejoras, comentarios) {
  let total = 0;
  if (comunicacion === 'buena') total = 20;
  if (comunicacion === 'regular') total = 50;
  if (comunicacion === 'mala') total = 80;
  total = total + cantMejoras * 8;

  const texto = comentarios.toLowerCase();
  const malas = ['malo', 'pesimo', 'peor', 'horrible', 'nunca', 'no entiendo', 'no explica', 'aburrido'];
  const buenas = ['bueno', 'claro', 'fácil', 'entretenido', 'agradable', 'excelente'];

  for (const palabra of malas) {
    if (texto.includes(palabra)) total += 10;
  }

  for (const palabra of buenas) {
    if (texto.includes(palabra)) total -= 8;
  }

  if (total < 0) total = 0;
  if (total > 100) total = 100;

  return total;
}

function crearMensaje(puntaje, docente) {
  if (puntaje >= 75) return 'Muy malo. ' + docente + ' necesita mejora urgente.';
  if (puntaje >= 50) return 'Malo. ' + docente + ' muestra problemas importantes.';
  if (puntaje >= 30) return 'Regular. Hay áreas a mejorar para que la experiencia sea más positiva.';
  return 'Aceptable. La percepción no es mala, pero siempre hay espacio para mejorar.';
}

// Arma la respuesta con las 3 barras y el mensaje
function armarRespuesta(e, alumno, docente) {
  return {
    id: e.id,
    fecha: e.fecha,
    alumno,
    docente,
    comunicacion: e.comunicacion,
    cantMejoras: e.cantMejoras,
    comentarios: e.comentarios,
    puntaje: e.puntaje,
    malo: e.puntaje,
    regular: 100 - Math.abs(e.puntaje - 50) * 2,
    bueno: 100 - e.puntaje,
    mensaje: crearMensaje(e.puntaje, docente.nombre)
  };
}

// Consultar solamente las encuestas del alumno que inició sesión
router.get('/mis', verificarToken, async (req, res) => {
  try {
    const [filas] = await db.query(`
      SELECT e.*, 
        a.nombre AS alumnoNombre, a.email, a.curso,
        d.nombre AS docenteNombre, d.materia
      FROM Encuesta e
      JOIN Alumno a ON e.alumno_id = a.id
      JOIN Docente d ON e.docente_id = d.id
      WHERE e.alumno_id = ?
      ORDER BY e.fecha DESC, e.id DESC
    `, [req.usuario.id]);

    res.json(filas.map(f => armarRespuesta(
      f,
      { id: f.alumno_id, nombre: f.alumnoNombre, email: f.email, curso: f.curso },
      { id: f.docente_id, nombre: f.docenteNombre, materia: f.materia }
    )));

  } catch (error) {
    console.error(error);
    res.status(500).json({ mensaje: 'No se pudieron cargar tus encuestas' });
  }
});

// Consultar encuestas propias (no las de otros alumnos)
router.get('/', verificarToken, async (req, res) => {
  try {
    const [filas] = await db.query(`
      SELECT e.*,
        a.nombre AS alumnoNombre, a.email, a.curso,
        d.nombre AS docenteNombre, d.materia
      FROM Encuesta e
      JOIN Alumno a ON e.alumno_id = a.id
      JOIN Docente d ON e.docente_id = d.id
      WHERE e.alumno_id = ?
      ORDER BY e.fecha DESC, e.id DESC
    `, [req.usuario.id]);

    res.json(filas.map(f => armarRespuesta(
      f,
      { id: f.alumno_id, nombre: f.alumnoNombre, email: f.email, curso: f.curso },
      { id: f.docente_id, nombre: f.docenteNombre, materia: f.materia }
    )));

  } catch (error) {
    console.error(error);
    res.status(500).json({ mensaje: 'No se pudieron cargar las encuestas' });
  }
});

// Enviar encuesta y guardarla en MySQL
router.post('/', verificarToken, async (req, res) => {
  try {
    const { docente, comunicacion } = req.body;
    const cantMejoras = Number(req.body.cantMejoras || 0);
    const comentarios = req.body.comentarios || '';

    if (
      !docente?.id ||
      !['buena', 'regular', 'mala'].includes(comunicacion) ||
      !Number.isInteger(cantMejoras) ||
      cantMejoras < 0 ||
      cantMejoras > 5 ||
      typeof comentarios !== 'string' ||
      comentarios.length > 500
    ) {
      return res.status(400).json({
        mensaje: 'Los datos de la encuesta no son válidos'
      });
    }

    // El alumno se obtiene del token, no del navegador
    const [alumnos] = await db.query(
      'SELECT id, nombre, email, curso FROM Alumno WHERE id = ?',
      [req.usuario.id]
    );

    if (alumnos.length === 0) {
      return res.status(404).json({ mensaje: 'No existe el alumno' });
    }

    const [docentes] = await db.query(
      'SELECT id, nombre, materia FROM Docente WHERE id = ?',
      [docente.id]
    );

    if (docentes.length === 0) {
      return res.status(404).json({ mensaje: 'No existe el docente' });
    }

    const puntaje = calcularPuntaje(
      comunicacion,
      cantMejoras,
      comentarios
    );

    const fecha = new Date().toISOString().slice(0, 10);

    const [r] = await db.query(
      `INSERT INTO Encuesta
      (fecha, alumno_id, docente_id, comunicacion, cantMejoras, comentarios, puntaje)
      VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [
        fecha,
        alumnos[0].id,
        docentes[0].id,
        comunicacion,
        cantMejoras,
        comentarios,
        puntaje
      ]
    );

    res.json(armarRespuesta(
      { id: r.insertId, fecha, comunicacion, cantMejoras, comentarios, puntaje },
      alumnos[0],
      docentes[0]
    ));

  } catch (error) {
    console.error(error);
    res.status(500).json({ mensaje: 'No se pudo guardar la encuesta' });
  }
});

// Malo / regular / bueno por curso
router.get('/estadisticas', async (req, res) => {
  try {
    const [filas] = await db.query(`
      SELECT a.curso, COUNT(*) AS total,
        SUM(e.puntaje >= 50) AS malos,
        SUM(e.puntaje >= 30 AND e.puntaje < 50) AS regulares,
        SUM(e.puntaje < 30) AS buenos
      FROM Encuesta e
      JOIN Alumno a ON e.alumno_id = a.id
      GROUP BY a.curso
      ORDER BY a.curso
    `);

    res.json(filas.map(f => ({
      ...f,
      total: +f.total,
      malos: +f.malos,
      regulares: +f.regulares,
      buenos: +f.buenos
    })));

  } catch (error) {
    console.error(error);
    res.status(500).json({ mensaje: 'No se pudieron cargar las estadísticas' });
  }
});

module.exports = router;
