
const router = require('express').Router();
const db = require('../db');
const bcrypt = require('bcryptjs');
const { crearToken } = require('../auth');

// Lista de alumnos (sin mostrar contraseñas)
router.get('/', async (req, res) => {
  const [filas] = await db.query(
    'SELECT id, nombre, email, curso FROM Alumno'
  );
  res.json(filas);
});

// Buscar alumno por email (sin mostrar contraseña)
router.get('/email/:email', async (req, res) => {
  const email = req.params.email.trim().toLowerCase();

  const [filas] = await db.query(
    'SELECT id, nombre, email, curso FROM Alumno WHERE email = ?',
    [email]
  );

  if (filas.length === 0) {
    return res.status(404).json({ mensaje: 'No hay cuenta con ese email' });
  }

  res.json(filas[0]);
});

// Iniciar sesión
router.post('/login', async (req, res) => {
  const email = (req.body.email || '').trim().toLowerCase();
  const password = req.body.password || '';

  const [filas] = await db.query(
    'SELECT id, nombre, email, curso, password FROM Alumno WHERE email = ?',
    [email]
  );

  if (filas.length === 0 || !filas[0].password) {
    return res.status(401).json({ mensaje: 'Email o contraseña incorrectos' });
  }

  const coincide = await bcrypt.compare(password, filas[0].password);

  if (!coincide) {
    return res.status(401).json({ mensaje: 'Email o contraseña incorrectos' });
  }

  const { id, nombre, curso } = filas[0];
  const token = crearToken({ id, email });

  res.json({ id, nombre, email, curso, token });
});

// Crear cuenta
router.post('/', async (req, res) => {
  const { nombre, curso } = req.body;
  const email = (req.body.email || '').trim().toLowerCase();
  const password = req.body.password || '';

  if (!nombre || !curso || !email || password.length < 8) {
    return res.status(400).json({
      mensaje: 'Completá todos los campos. La contraseña debe tener al menos 8 caracteres.'
    });
  }

  const [existe] = await db.query(
    'SELECT id FROM Alumno WHERE email = ?',
    [email]
  );

  if (existe.length > 0) {
    return res.status(409).json({
      mensaje: 'Ya existe una cuenta con ese email'
    });
  }

  const passwordEncriptada = await bcrypt.hash(password, 10);

  const [r] = await db.query(
    'INSERT INTO Alumno (nombre, email, curso, password) VALUES (?, ?, ?, ?)',
    [nombre.trim(), email, curso, passwordEncriptada]
  );

  const alumno = {
    id: r.insertId,
    nombre: nombre.trim(),
    email,
    curso
  };

  const token = crearToken(alumno);

  res.json({ ...alumno, token });
});

module.exports = router;

